extends Label


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$PointsLabel.text = str(points)

var points = 0
func update_points(amount : int) -> void:
	points += amount
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$PointsLabel.text = str(points)
