extends Area2D

class_name Feathers

@export var type: String
@onready var Player = $Player/Area2D

const good_feather_pic = preload("res://images/goodfeather.png")
const bad_feather_pic = preload("res://images/badfeather.png")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	set_data()
	connect_signals()
	
func set_data() -> void:
	if type == "good_feather":
		%Sprite2D.texture = good_feather_pic
	elif type == "bad_feather":
		%Sprite2D.texture = bad_feather_pic

func connect_signals() -> void:
	connect("on_body_entered", collect)
	
func collect(body : Area2D) -> void:
	if body == Player: 
		if type == "good_feather":
			body.update_points(1)
		elif type == "bad_feather":
			body.update_points(-1)
	

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass
