extends Area2D

class_name Feathers

@export var type: String

#const good_feather_pic = preload("res://images/goodfeather.png")
#const bad_feather_pic = preload("res://images/badfeather.png")

func _ready() -> void:
	#set_data()
	body_entered.connect(_on_body_entered)
	
#func set_data() -> void:
	#if type == "good_feather":
		#$Sprite2D.texture = good_feather_pic
	#elif type == "bad_feather":
		#$Sprite2D.texture = bad_feather_pic

func _on_body_entered(body: Node2D) -> void:
	queue_free() 
